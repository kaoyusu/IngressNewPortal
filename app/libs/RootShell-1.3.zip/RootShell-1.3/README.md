RootShell provides rooted developers with an easy to use Root Shell for their Android Applications.

You can find the latest release here: https://github.com/Stericson/RootShell/releases

You can find more information at our wiki: https://github.com/Stericson/RootShell/wiki
